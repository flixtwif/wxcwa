Windows 10 free customisation.
Using these scripts you will be able to edit personalisation settings that are locked in Windows settings until Windows is activated.
Using this program you can edit:
-Desktop background
-Theme settings
-Various settings relating to the accent colour
-Taskbar settings
-more

This program was made for Windows 10 and was tested in Windows 10 22H2. The program will lose some features when used on Windows 11 and will not work at all on other Windows versions.

@flixtwif on Twitter/X

!!! Run the Personalisation file as an Administrator !!!